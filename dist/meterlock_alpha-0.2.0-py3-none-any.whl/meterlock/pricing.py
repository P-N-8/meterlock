from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Pricing:
    # Nanodollars/token. Frozen from the accepted Stage-A proof pricing basis.
    # short: $0.20 input / $0.02 cached / $1.20 output per 1M
    # long (>272K input): 2x input/cache and 1.5x output.
    short_input_nd: int = 200
    short_cached_input_nd: int = 20
    short_output_nd: int = 1_200
    long_input_nd: int = 400
    long_cached_input_nd: int = 40
    long_output_nd: int = 1_800
    long_context_threshold: int = 272_000


LUNA = Pricing()


def reservation_cost_nd(input_upper_bound: int, max_output_tokens: int) -> int:
    """Reserve at long-context rates so a pricing-tier transition cannot under-reserve."""
    return input_upper_bound * LUNA.long_input_nd + max_output_tokens * LUNA.long_output_nd


def actual_cost_nd(usage: dict[str, Any]) -> int:
    input_tokens = int(usage["input_tokens"])
    output_tokens = int(usage["output_tokens"])
    details = usage.get("input_tokens_details") or {}
    cached_tokens = int(details.get("cached_tokens") or 0)
    if cached_tokens < 0 or cached_tokens > input_tokens:
        raise ValueError("invalid cached token count")

    uncached = input_tokens - cached_tokens
    if input_tokens > LUNA.long_context_threshold:
        return (
            uncached * LUNA.long_input_nd
            + cached_tokens * LUNA.long_cached_input_nd
            + output_tokens * LUNA.long_output_nd
        )
    return (
        uncached * LUNA.short_input_nd
        + cached_tokens * LUNA.short_cached_input_nd
        + output_tokens * LUNA.short_output_nd
    )
